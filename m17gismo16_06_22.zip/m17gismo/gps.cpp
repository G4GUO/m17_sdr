#include <math.h>
#include <string.h>
#include "m17defines.h"

GpsMsg m_gps;

void gps_decode(uint8_t *b, GpsMsg *msg){

	uint16_t n;
    uint48_t w;

	msg->lat = (int8_t)b[0];// lat degrees
    n = pack_8_to_16(&b[1]);// lat fraction
    msg->lat += n/65536.0;

    msg->lon  = (int16_t)pack_8_to_16(&b[3]); // long deg int
    n    = pack_8_to_16(&b[5]);// long fraction
    msg->lon += n/65536.0;

    msg->alt = pack_8_to_16(&b[7]) - 1500;// Alt

    w = pack_8_to_48(&b[9]);
    msg->course =  w>>38;
    msg->speed  = (w>>28)&0x3FF;
    msg->object =  w&0xFFFFF;
}

void gps_encode(uint8_t *b, GpsMsg *msg){
	double frac,ip;
	uint16_t n;
    uint48_t w;

    // Lattitude
	frac = modf(msg->lat,&ip);
    b[0] = ip;
    n = frac*65536;
    pack_16_to_8(n,&b[1]);

    // Longitude
	frac = modf(msg->lon,&ip);
    pack_16_to_8(n,&b[3]);
    n = frac*65536;
    pack_16_to_8(n,&b[5]);

    // Altitude
    pack_16_to_8(msg->alt+1500,&b[7]);
    // Course
    w = msg->course;
    w <<= 10;
    w |= msg->speed;
    w <<= 20;
}
void gps_nmea_parse(char *nmea){
	int nt = 0;
	char *token[25];
	token[nt] = strtok(nmea,",");
	while(token[nt] != NULL){
		if( ++nt == 25 ) break;
		token[nt] = strtok(NULL,",");
	}

	//MSG

	// TIME
	// Latidude
	// N/S
	// Longitude
	// W/E
	// WE
	// Quality
	// Number of satellites
	// HDOP
	// Altitude
	// Units M eters or feet
	// Geoidal seperation
	// Units

}
void gps_open(void){

}
void gps_close(void){

}
